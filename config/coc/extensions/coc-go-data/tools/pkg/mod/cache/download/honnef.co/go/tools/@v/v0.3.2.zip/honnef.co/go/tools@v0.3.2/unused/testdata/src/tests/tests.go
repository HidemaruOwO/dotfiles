package pkg

func fn() {} //@ used(false), used_test(true)
