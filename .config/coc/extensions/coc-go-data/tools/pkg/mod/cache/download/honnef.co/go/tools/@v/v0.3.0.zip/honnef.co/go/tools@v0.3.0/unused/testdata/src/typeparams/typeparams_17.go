//go:build !go1.18

package pkg
